
package shop.generator;

import shop.Customer;
import shop.Order;
import shop.Product;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ShopGenerator {

    private static final Random RANDOM = new Random();

    public static List<Product> generateProducts(int numProducts) {
        List<Product> products = new ArrayList<>();
        for (int i = 0; i < numProducts; i++) {
            products.add(new Product(generateUniqueId("PROD_"), "Product" + i, RANDOM.nextDouble() * 100));
        }
        return products;
    }

    public static List<Order> generateOrders(List<Product> products, int numOrders) {
        List<Order> orders = new ArrayList<>();
        for (int i = 0; i < numOrders; i++) {
            List<Product> orderProducts = new ArrayList<>();
            int numOrderProducts = 1 + RANDOM.nextInt(Math.min(5, products.size())); // At least one product per order
            for (int j = 0; j < numOrderProducts; j++) {
                orderProducts.add(products.get(RANDOM.nextInt(products.size())));
            }
            orders.add(new Order(generateUniqueId("ORD_"), orderProducts));
        }
        return orders;
    }

    public static Customer generateCustomer(List<Product> products, int maxOrders) {
        List<Order> orders = generateOrders(products, 1 + RANDOM.nextInt(maxOrders)); // At least one order
        return new Customer(generateUniqueId("CUST_"), "CustomerName", orders);
    }

    private static String generateUniqueId(String prefix) {
        return prefix + Long.toString(System.nanoTime() + RANDOM.nextInt(10000));
    }
}
