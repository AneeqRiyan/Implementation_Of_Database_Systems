package shop.generator;

import shop.Customer;
import shop.Order;
import shop.Product;

import java.util.List;

// TODO: Task 2.2 a)
public class ShopGenerator {
    public static List<Product> generateProducts(int numProducts) {
        // TODO
        return null;
    }

    public static List<Order> generateOrders(List<Product> products, int numOrders) {
        // TODO
        return null;
    }

    public static Customer generateCustomer(List<Product> products, int maxOrders) {
        // TODO
        return null;
    }

}
