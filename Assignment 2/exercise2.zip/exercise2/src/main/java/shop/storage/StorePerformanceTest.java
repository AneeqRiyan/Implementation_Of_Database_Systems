package shop.storage;

import shop.generator.CustomerDatabase;

public class StorePerformanceTest {

    public static void main(String[] args) {
        CustomerDatabase customerDatabase = new CustomerDatabase(2_000, 10, 5);

        // TODO: Task 2.2 d)
    }
}
