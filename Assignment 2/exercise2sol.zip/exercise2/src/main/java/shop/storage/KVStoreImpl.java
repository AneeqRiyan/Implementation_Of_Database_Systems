package shop.storage;

import shop.Customer;

// TODO: Task 2.2 c)
public class KVStoreImpl implements CustomerStore, CustomerStoreQuery {
    @Override
    public void open() {
        // TODO
    }

    @Override
    public void insertCustomer(Customer customer) {
        // TODO
    }

    @Override
    public void close() {
        // TODO
    }

    @Override
    public void cleanUp() {
        // TODO
    }

    @Override
    public void queryAllUsers() {
        // TODO
    }

    @Override
    public void queryTopProduct() {
        // TODO
    }
}
